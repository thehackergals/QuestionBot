/*:
 ## Wrapup
 You’ve put a lot of work into giving QuestionBot a brain, and you've seen how useful playgrounds can be for working on a single function without distraction.
 
 The final part of the lesson is to take the new function you built on the previous page, and put it into the app.
 
 The instructions for doing this are in your Guide, in the QuestionBot lesson.*/
/*:
 _Copyright (C) 2016 Apple Inc. All Rights Reserved.\
 See LICENCE.txt for this sample’s licensing information_
 */
//:[Previous](@previous)  |  page 7 of 7
